# system-design-notes.md placeholder
